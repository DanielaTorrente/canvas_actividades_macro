# Canvas de Actividades Docentes - Macro Básica

Proyecto React + Vite para planificar actividades docentes de manera interactiva.

## Scripts útiles

- `npm run dev` ➔ Levanta en desarrollo local
- `npm run build` ➔ Genera versión optimizada para producción

## Hecho para: Cátedra de Macroeconomía Básica
